# PyContext

Install it with `pip install pycontext-lib`. Import the `context` library and explore the many context related properties!